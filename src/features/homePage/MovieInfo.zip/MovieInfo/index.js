export { default as MovieInfo } from './MovieInfo';
